


class Product:
    def __init__(self,name,price):
        self.name = name
        self.price = price

    def display_info(self):
        print(f"Product Name: {self.name}")
        print(f"Product Price: {self.price}") 


        
